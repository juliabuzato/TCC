package br.com.tcc.tabs;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class FragmentoPonto extends Fragment {
 //   public LinearLayout layout1, layout2, layout3, layout4;
    Button btnInicio, btnIntervalo, btnVoltar, btnSaida;

    private static final int v = 1;


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("users");
    String entrada;
    String entradaHora;
    String entradaMinuto;
    String intervalo;
    String intervaloHora;
    String intervaloMinuto;
    String saidaIntervalo;
    String saidaIntervaloHora;
    String saidaIntervaloMinuto;
    String saida;
    String saidaHora;
    String saidaMinuto;
    String userId = "1";
    int totalHoras;
    int totalMinutos;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        final View view = inflater.inflate(R.layout.fragmento_ponto, container, false);

        DatabaseReference myRefRead = database.getReference("users").child("1").child("dados");
        // Read from the database
        myRefRead.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Dados value = dataSnapshot.getValue(Dados.class);
                final String nomeBuscado = value.nome;
                final TextView nomeUser = view.findViewById(R.id.nomeUsuario);
                nomeUser.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        nomeUser.setText("Olá, " + nomeBuscado);

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        /*

        Button bt = view.findViewById(R.id.bt);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText( getActivity() , "Clicado BT Fragment" , Toast.LENGTH_LONG).show();
            }
        });

         */



        return view;
    }

    private void writeNewUser(String entrada, String intervalo, String saidaIntervalo, String saida, String userId, String data, int totalHoras, int totalMinutos, String totalDia) {
        HorasTrabalhadas horasTrabalhadas = new HorasTrabalhadas(entrada, intervalo, saidaIntervalo, saida, totalHoras, totalMinutos, totalDia);

        myRef.child(userId).child("Calendario").child(data).setValue(horasTrabalhadas);
    }

    public String getData(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date data = new Date();
        Calendar  cal = Calendar.getInstance();
        cal.setTime(data);
        Date data_atual = cal.getTime();
        String data_completa = dateFormat.format(data_atual);
        return data_completa;
    }

    public void calculaTotalHoras (String entradaHora, String intervaloHora, String saidaIntervaloHora, String saidaHora){

        int intEntrada = Integer.parseInt(entradaHora);
        int intIntervalo = Integer.parseInt(intervaloHora);
        int intSaidaIntervalo = Integer.parseInt(saidaIntervaloHora);
        int intSaida = Integer.parseInt(saidaHora);
        totalHoras = (intIntervalo - intEntrada) + (intSaida - intSaidaIntervalo);
    }

    public void somaMinutos(String entradaMinuto, String intervaloMinuto, String saidaIntervaloMinuto, String saidaMinuto){

        int intEntrada = Integer.parseInt(entradaMinuto);
        int intIntervalo = Integer.parseInt(intervaloMinuto);
        int intSaidaIntervalo = Integer.parseInt(saidaIntervaloMinuto);
        int intSaida = Integer.parseInt(saidaMinuto);
        totalMinutos = (intIntervalo - intEntrada) + (intSaida - intSaidaIntervalo);
        while(totalMinutos >= 60){
            totalMinutos -= 60;
            totalHoras += 1;
        }
    }

    public void onButtonHorasClicked(View v){
        SimpleDateFormat dateFormat_hora = new SimpleDateFormat("HH");
        SimpleDateFormat dateFormat_minuto = new SimpleDateFormat("mm");
        Date data = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(data);
        Date data_atual = cal.getTime();
        String hora_atual = dateFormat_hora.format(data_atual);
        String minuto_atual = dateFormat_minuto.format(data_atual);


        switch(v.getId()) {//pega o id da view que chamou o método
            case R.id.btnEntrar:

                ((Button)v.findViewById(R.id.btnEntrar)).setEnabled(false);
                ((Button)v.findViewById(R.id.btnIntervalo)).setVisibility(View.VISIBLE);
                TextView textoEntrar = v.findViewById(R.id.btnEntrar);
                textoEntrar.setText(hora_atual + ":" + minuto_atual);
                entradaHora = hora_atual;
                entradaMinuto = minuto_atual;
                entrada = entradaHora + ":" + entradaMinuto;
                break;

            case R.id.btnIntervalo:
                ((Button)v.findViewById(R.id.btnIntervalo)).setEnabled(false);
                ((Button)v.findViewById(R.id.btnVoltar)).setVisibility(View.VISIBLE);
                TextView textoIntervalo = v.findViewById(R.id.btnIntervalo);
                textoIntervalo.setText(hora_atual + ":" + minuto_atual);
                intervaloHora = hora_atual;
                intervaloMinuto = minuto_atual;
                intervalo = intervaloHora + ":" + intervaloMinuto;
                break;

            case R.id.btnVoltar:
                ((Button)v.findViewById(R.id.btnVoltar)).setEnabled(false);
                ((Button)v.findViewById(R.id.btnSaida)).setVisibility(View.VISIBLE);
                TextView textoVoltar = v.findViewById(R.id.btnVoltar);
                textoVoltar.setText(hora_atual + ":" + minuto_atual);
                saidaIntervaloHora = hora_atual;
                saidaIntervaloMinuto = minuto_atual;
                saidaIntervalo = saidaIntervaloHora + ":" + saidaIntervaloMinuto;
                break;

            case R.id.btnSaida:
                ((Button)v.findViewById(R.id.btnSaida)).setEnabled(false);
                TextView textoSair = v.findViewById(R.id.btnSaida);
                textoSair.setText(hora_atual + ":" + minuto_atual);
                saidaHora = hora_atual;
                saidaMinuto = minuto_atual;
                saida = saidaHora + ":" + saidaMinuto;
                somaMinutos(entradaMinuto, intervaloMinuto, saidaIntervaloMinuto, saidaMinuto);
                calculaTotalHoras(entradaHora, intervaloHora, saidaIntervaloHora, saidaHora);
                String totalDia = totalHoras +":"+ totalMinutos;
                writeNewUser(entrada, intervalo, saidaIntervalo, saida, userId, getData(), totalHoras, totalMinutos, totalDia);
                break;
        }
    }


}
