package br.com.tcc.tabs;


import com.google.firebase.database.IgnoreExtraProperties;

public class Dados {
    public String nome;

    public Dados() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public Dados(String nome) {
        this.nome = nome;
    }
}
